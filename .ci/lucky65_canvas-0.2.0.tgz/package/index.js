'use strict';

const os = require('node:os');
if (Number(process.versions.node.split('.')[0]) < 22) {
    throw new Error('lucky65_canvas requires Node.js 22 or newer.');
}
if (process.arch !== 'x64') throw new Error('lucky65_canvas currently supports x64 only.');
if (process.platform === 'win32') {
    if (Number(os.release().split('.')[0]) < 10) throw new Error('lucky65_canvas requires Windows 10/11.');
    module.exports = require('./canvas.node');
} else if (process.platform === 'linux') {
    if (!process.report.getReport().header.glibcVersionRuntime) {
        throw new Error('lucky65_canvas currently supports glibc Linux; Alpine/musl is not supported.');
    }
    let backend;
    try { backend = require('@napi-rs/canvas'); }
    catch (cause) { throw new Error('Linux Canvas backend could not load. Install with npm install --include=optional lucky65_canvas.', { cause }); }
    module.exports = require('./linux.js')(backend);
} else {
    throw new Error('lucky65_canvas supports Windows 10/11 x64 and glibc Linux x64.');
}

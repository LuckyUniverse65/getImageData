'use strict';

// Linux compatibility backend for ordinary drawing, not Chrome pixel matching.
// A factory also allows its drawing logic to be tested independently of routing.
module.exports = function createLinuxBackend(backend) {
    const { DOMMatrix, DOMMatrixReadOnly, DOMPoint, DOMPointReadOnly } = require('./dommatrix.js');
    const canvasPixels = Symbol('canvas backing store');
    const state = new WeakMap();
    const closedBitmaps = new WeakSet();
    const bitmapKey = Symbol('ImageBitmap construction');
    const nativeWidth = Object.getOwnPropertyDescriptor(backend.CanvasElement.prototype, 'width');
    const nativeHeight = Object.getOwnPropertyDescriptor(backend.CanvasElement.prototype, 'height');
    const nativeContext = backend.CanvasElement.prototype.getContext;
    const invalid = message => new DOMException(message, 'InvalidStateError');
    const unsupported = message => new DOMException(message, 'NotSupportedError');
    const dimension = value => {
        const number = +value;
        if (!Number.isFinite(number) || number < 0 || number > 0x7fffffff) throw new RangeError('Invalid canvas dimension');
        return Math.trunc(number);
    };
    const rawContext = canvas => nativeContext.call(canvas, '2d');

    class CanvasBase extends backend.CanvasElement {
        constructor(width, height) {
            super(dimension(width), dimension(height));
            state.set(this, { context: null, transferred: false });
        }
        get width() { return nativeWidth.get.call(this); }
        set width(value) {
            if (state.get(this)?.transferred) throw invalid('Canvas control was transferred');
            nativeWidth.set.call(this, dimension(value));
        }
        get height() { return nativeHeight.get.call(this); }
        set height(value) {
            if (state.get(this)?.transferred) throw invalid('Canvas control was transferred');
            nativeHeight.set.call(this, dimension(value));
        }
        getContext(type, options) {
            const current = state.get(this);
            if (!current) throw new TypeError('Illegal invocation');
            if (current.transferred) throw invalid('Canvas control was transferred');
            if (!arguments.length) throw new TypeError('getContext requires a context id');
            // This Linux backend deliberately does not advertise WebGL/WebGPU.
            if (String(type) !== '2d') return null;
            if (!current.context) current.context = nativeContext.call(this, '2d', options);
            return current.context;
        }
        [canvasPixels]() {
            return rawContext(this).getImageData(0, 0, this.width, this.height).data;
        }
    }

    class ImageBitmap extends backend.CanvasElement {
        constructor(key, width, height) {
            if (key !== bitmapKey) throw new TypeError('Illegal constructor');
            super(width, height);
        }
        get width() { return nativeWidth.get.call(this); }
        get height() { return nativeHeight.get.call(this); }
        close() {
            if (closedBitmaps.has(this)) return;
            nativeWidth.set.call(this, 0);
            nativeHeight.set.call(this, 0);
            closedBitmaps.add(this);
        }
    }

    class OffscreenCanvas extends CanvasBase {
        constructor(width, height) {
            if (arguments.length < 2) throw new TypeError('OffscreenCanvas requires width and height');
            super(width, height);
        }
        transferToImageBitmap() {
            if (!this.width || !this.height || !state.get(this).context) throw invalid('Canvas has no drawable context');
            const bitmap = new ImageBitmap(bitmapKey, this.width, this.height);
            rawContext(bitmap).drawImage(this, 0, 0);
            // putImageData ignores transforms and clipping, preserving the
            // caller's drawing state while clearing the transferred pixels.
            rawContext(this).putImageData(new backend.ImageData(this.width, this.height), 0, 0);
            return bitmap;
        }
    }

    class HTMLCanvasElement extends CanvasBase {
        constructor(width = 300, height = 150) { super(width, height); }
        transferControlToOffscreen() {
            const current = state.get(this);
            if (current.context || current.transferred) throw invalid('Canvas already has a context or was transferred');
            // Synchronizing a DOM placeholder's presentation is not supported.
            // Keep this explicit instead of returning an unrelated surface.
            throw unsupported('Linux HTMLCanvasElement transfer is not implemented; construct OffscreenCanvas directly');
        }
    }

    async function createImageBitmap(source, ...args) {
        if (closedBitmaps.has(source)) throw invalid('ImageBitmap is closed');
        if (source instanceof Blob) source = await backend.loadImage(Buffer.from(await source.arrayBuffer()));
        if (source instanceof backend.ImageData) {
            const canvas = backend.createCanvas(source.width, source.height);
            rawContext(canvas).putImageData(source, 0, 0);
            source = canvas;
        }
        if (!(source instanceof backend.CanvasElement) && !(source instanceof backend.Image)) {
            throw new TypeError('Expected a Canvas, ImageData, ImageBitmap, Image or Blob');
        }
        let sx = 0, sy = 0, sw = source.width, sh = source.height, options = {};
        if (args.length >= 4) {
            [sx, sy, sw, sh] = args.slice(0, 4).map(Number);
            options = args[4] ?? {};
        } else if (args.length <= 1) {
            options = args[0] ?? {};
        } else throw new TypeError('Invalid createImageBitmap arguments');
        if (![sx, sy, sw, sh].every(Number.isFinite) || !sw || !sh || !source.width || !source.height) {
            throw new RangeError('Invalid bitmap dimensions');
        }
        if (sw < 0) { sx += sw; sw = -sw; }
        if (sh < 0) { sy += sh; sh = -sh; }
        for (const name of ['premultiplyAlpha', 'colorSpaceConversion']) {
            if (options[name] !== undefined && options[name] !== 'default') {
                throw unsupported(name + ' overrides are not supported by the Linux adapter');
            }
        }
        const orientation = options.imageOrientation ?? 'from-image';
        if (!['from-image', 'none', 'flipY'].includes(orientation)) throw new TypeError('Invalid imageOrientation');
        let width = options.resizeWidth === undefined ? null : dimension(options.resizeWidth);
        let height = options.resizeHeight === undefined ? null : dimension(options.resizeHeight);
        if (width === null) width = height === null ? Math.trunc(sw) : Math.max(1, Math.ceil(sw * height / sh));
        if (height === null) height = options.resizeWidth === undefined ? Math.trunc(sh) : Math.max(1, Math.ceil(sh * width / sw));
        if (!width || !height) throw new RangeError('Bitmap dimensions must be positive');
        const bitmap = new ImageBitmap(bitmapKey, width, height);
        const ctx = rawContext(bitmap);
        const quality = options.resizeQuality ?? 'low';
        if (!['pixelated', 'low', 'medium', 'high'].includes(quality)) throw new TypeError('Invalid resizeQuality');
        ctx.imageSmoothingEnabled = quality !== 'pixelated';
        if (quality !== 'pixelated') ctx.imageSmoothingQuality = quality;
        if (orientation === 'flipY') { ctx.translate(0, height); ctx.scale(1, -1); }
        ctx.drawImage(source, sx, sy, sw, sh, 0, 0, width, height);
        return bitmap;
    }

    function encodeImage(pixels, width, height, type = 'image/png', quality) {
        width = dimension(width); height = dimension(height);
        if (!width || !height) return undefined;
        if (!ArrayBuffer.isView(pixels) || pixels.BYTES_PER_ELEMENT !== 1 || pixels.length !== width * height * 4) {
            throw new TypeError('Expected width * height * 4 RGBA bytes');
        }
        const canvas = backend.createCanvas(width, height);
        rawContext(canvas).putImageData(new backend.ImageData(new Uint8ClampedArray(pixels), width, height), 0, 0);
        type = String(type).toLowerCase();
        if (!['image/png', 'image/jpeg', 'image/webp'].includes(type)) type = 'image/png';
        const percentage = typeof quality === 'number' && quality >= 0 && quality <= 1 ? Math.round(quality * 100) : undefined;
        return canvas.encodeSync(type.slice(6), type === 'image/png' ? undefined : percentage);
    }

    function decodeImage() {
        throw unsupported('Synchronous decodeImage is not supported on Linux; await createImageBitmap(blob) or loadImage(bytes)');
    }

    const sample = backend.createCanvas(1, 1);
    const context = sample.getContext('2d');
    const api = {
        OffscreenCanvas, HTMLCanvasElement,
        CanvasRenderingContext2D: context.constructor,
        OffscreenCanvasRenderingContext2D: context.constructor,
        ImageData: backend.ImageData, ImageBitmap, createImageBitmap,
        CanvasGradient: context.createLinearGradient(0, 0, 1, 1).constructor,
        CanvasPattern: context.createPattern(sample, 'repeat').constructor,
        TextMetrics: context.measureText('').constructor,
        Path2D: backend.Path2D, DOMMatrix, DOMMatrixReadOnly, DOMPoint, DOMPointReadOnly,
        encodeImage, decodeImage, canvasPixels,
        // Linux helpers for loading images and registering application fonts.
        Image: backend.Image, loadImage: backend.loadImage, GlobalFonts: backend.GlobalFonts,
        getRenderDiagnostics() {
            return JSON.stringify({ platform: process.platform, arch: process.arch,
                defaultBackend: 'napi-rs-skia-cpu', backendVersion: '1.1.0', selectedAdapter: null,
                chromePixelMatching: false, availableFontFamilies: backend.GlobalFonts.families.map(font => font.family) });
        }
    };
    if (globalThis.Float16Array) api.Float16Array = globalThis.Float16Array;
    return api;
};

# lucky65_canvas

Windows / Linux 上的 Node.js Canvas 2D / OffscreenCanvas，使用 Skia 执行绘图和文字渲染，提供像素读写与 PNG、JPEG、WebP 编码。

作者微信号：`LuckyUniverse65`

## 安装

```bash
npm install lucky65_canvas
```

`0.2.0` 起支持 **Windows 10/11 x64 和 Linux x64（glibc）、Node.js 22 及以上**。安装无需 Rust、Visual Studio、Skia 源码、Chrome 或桌面环境。

| 平台 | 实现与用途 |
| --- | --- |
| Windows 10/11 x64 | 本项目预编译原生模块，保留原有 Windows 渲染实现 |
| Linux x64（glibc，面向 Ubuntu/Debian） | `@napi-rs/canvas@1.1.0` 的预编译 Skia CPU 后端及本项目接口适配，满足普通绘图需求，无需 GPU |

Linux 后端作为 npm 可选依赖安装，**不要使用 `--omit=optional`**；普通 `npm install lucky65_canvas` 会自动安装对应平台的预编译依赖，没有额外的安装编译或下载脚本。Windows 也可能安装该依赖，但运行时仍加载原 Windows 模块。

暂不支持 Windows Server、旧版 Windows、Alpine/musl、macOS、ARM64、x86。Linux 与 Windows 的字体和渲染实现不同，不保证像素一致，也不保证与 Linux Chrome 一致。

精简 Linux 镜像若缺少字体，Ubuntu/Debian 可执行：

```bash
sudo apt-get update
sudo apt-get install -y libfontconfig1 fonts-dejavu-core fonts-noto-cjk
```

## 使用

```js
const { OffscreenCanvas } = require('lucky65_canvas');

const canvas = new OffscreenCanvas(2, 1);
const ctx = canvas.getContext('2d');
ctx.fillStyle = 'red';
ctx.fillRect(0, 0, 1, 1);
console.log(Array.from(ctx.getImageData(0, 0, 2, 1).data));
// [255, 0, 0, 255, 0, 0, 0, 0]
```

ESM 使用默认导入后解构：

```js
import canvasAPI from 'lucky65_canvas';
const { OffscreenCanvas } = canvasAPI;
```

导出图片：

```js
const fs = require('node:fs/promises');
const { OffscreenCanvas } = require('lucky65_canvas');

async function main() {
    const canvas = new OffscreenCanvas(320, 100);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 320, 100);
    ctx.fillStyle = '#222222';
    ctx.font = '24px sans-serif';
    ctx.fillText('Hello Canvas', 20, 60);
    const blob = await canvas.convertToBlob({ type: 'image/png' });
    await fs.writeFile('canvas.png', Buffer.from(await blob.arrayBuffer()));
}
main().catch(console.error);
```

## 已有代码使用 require('canvas')

安装 `lucky65_canvas` 后应使用 `require('lucky65_canvas')`。如需保留已有的 `require('canvas')`，改用 npm 别名安装：

```bash
npm install canvas@npm:lucky65_canvas
```

这会把本包安装在 `canvas` 名下，不是安装 npm 上另一个同名 Canvas 项目。安装前确认项目没有同时依赖那个包的专属 API。

## 运行环境与结果

Windows 使用运行电脑可用的字体、图形设备与驱动，同时保留构建时选择的渲染后端及通用字体映射。Linux 使用 Skia CPU 与可用系统字体。换电脑后的像素结果可能变化，缺少字体时可能回退；安装不会自动校准到该电脑的 Chrome。

`build-info.json` 记录 **Windows 二进制** SHA-256、构建时间、渲染配置与历史 Chrome 校验摘要。历史校验只代表构建时机器和测试集，不适用于 Linux 后端。Windows 10 与其他电脑仍需独立验证。Windows 需要与本机 Chrome 对齐时，请按仓库的本机构建流程重新构建并校验。

查询当前进程渲染诊断：

```js
const { getRenderDiagnostics } = require('lucky65_canvas');
console.log(JSON.parse(getRenderDiagnostics()));
```

首次绘画有模块、字体和 GPU 初始化成本。Worker 中应各自 `require('lucky65_canvas')`，不要通过 `postMessage` 或 Piscina 参数传递整个模块对象；其中函数不可克隆。每个 Worker 有独立的模块实例和缓存。

## API 范围

| 类别 | 主要导出与功能 |
| --- | --- |
| Canvas | `OffscreenCanvas`、`HTMLCanvasElement`、两个 2D 上下文接口 |
| 绘画 | 路径、文字、渐变、图案、变换、裁剪、合成、阴影、滤镜 |
| 图像 | `ImageData`、`ImageBitmap`、`ImageBitmapRenderingContext`、`createImageBitmap`、`encodeImage`、`decodeImage` |
| 几何 | `Path2D`、`DOMMatrix`、`DOMMatrixReadOnly`、`DOMPoint`、`DOMPointReadOnly` |
| 返回类型 | `CanvasGradient`、`CanvasPattern`、`TextMetrics`、`Float16Array` |
| 诊断 | `getRenderDiagnostics` |

两平台均支持常规 Canvas 2D 绘画、文字测量、路径、渐变、图案、变换、`getImageData` / `putImageData` 和 `convertToBlob`。Linux 的上下文方法与类型细节由上述 CPU 后端提供，不承诺浏览器反射行为完全一致。

Linux 版的补充与限制：

- `createImageBitmap` 支持 Canvas、ImageData、Image、ImageBitmap、Blob，支持裁剪、缩放与 flipY；不支持非默认 premultiplyAlpha/colorSpaceConversion 覆盖。
- `transferToImageBitmap()` 支持提取像素并清空画布，保留绘画状态。
- `getContext('webgl'/'webgl2'/'webgpu'/'bitmaprenderer')` 返回 `null`，不导出 WebGL 兼容类型及 ImageBitmapRenderingContext。
- `HTMLCanvasElement.transferControlToOffscreen()` 与同步 `decodeImage()` 抛出 NotSupportedError。请直接创建 OffscreenCanvas，并使用 `await createImageBitmap(blob)` 或 `await loadImage(bytes)` 解码。
- Node.js 22 没有原生 Float16Array，Linux 不提供 Float16Array 兼容实现，rgba-float16 ImageData 不在此版本的 Node 22 支持范围内。
- Linux 额外导出 `Image`、`loadImage`、`GlobalFonts`，可通过 `GlobalFonts.registerFromPath('/path/font.ttf', 'MyFont')` 注册应用字体。
- DOMMatrix/DOMPoint 使用本项目实现；上下文返回的矩阵等对象可能属于后端自己的构造器，不应依赖跨后端的 instanceof 结果。

`HTMLCanvasElement` 是本地包装，不是真实 DOM 元素。Windows 包装没有 `toDataURL()` / `toBlob()`，Linux 后端额外提供这两个方法；跨平台图片导出推荐统一使用 `OffscreenCanvas.convertToBlob()`。Windows 的 WebGL 相关导出用于兼容接口，不是完整 WebGL GPU 绘画实现。

Windows 的完整 41 个顶层导出、44 个 2D 方法及属性说明见 [仓库 API 文档](https://github.com/LuckyUniverse65/getImageData#api-导出与方法)。Linux 以本页列出的接口范围及限制为准。

依赖组件的许可文本随包保留在 `THIRD_PARTY_NOTICES.txt`。
